package com.example.Kotlin_Project.model

import jakarta.persistence.*

@Entity // 이 클래스가 데이터베이스 테이블과 매핑됨을 나타냄
@Table(name = "employee") // 데이터베이스 테이블 이름 지정
data class Employee(
    @Id // Primary Key를 나타냄
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto Increment 설정
    @Column(name = "user_id") // 테이블의 컬럼 이름 매핑
    val userId: Int = 0,

    @Column(name = "name", nullable = false, length = 45) // NOT NULL, VARCHAR(45) 매핑
    val name: String = "",

    @Column(name = "specialty", nullable = false, length = 45) // NOT NULL, VARCHAR(45) 매핑
    val specialty: String = "",

    @Column(name = "user_email", nullable = true, length = 55) // NULL 허용, VARCHAR(55) 매핑
    val userEmail: String? = ""
)