package com.example.Kotlin_Project.controller

import com.example.Kotlin_Project.model.Project
import com.example.Kotlin_Project.service.ProjectService
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.*
import java.time.LocalDate
import org.springframework.http.ResponseEntity

@Controller
@RequestMapping("/projects") // 기본 URL 경로 설정
class ProjectController(private val projectService: ProjectService) {

    // 프로젝트 목록 페이지
    @GetMapping("/view")
    fun viewProjects(model: Model): String {
        val projects = projectService.findAll() // 모든 프로젝트 조회
        model.addAttribute("projects", projects) // 뷰로 데이터 전달
        return "projects" // templates/project-list.html 파일로 이동
    }
    // 프로젝트 삭제 처리
    @DeleteMapping("/{id}")
    fun deleteProject(@PathVariable id: Int): ResponseEntity<String> {
        return try {
            // ID에 해당하는 프로젝트 삭제
            projectService.deleteById(id)
            ResponseEntity.ok("프로젝트가 성공적으로 삭제되었습니다.")
        } catch (e: Exception) {
            // 예외 처리: ID가 존재하지 않거나 기타 문제 발생 시
            ResponseEntity.status(404).body("프로젝트 삭제에 실패했습니다: ${e.message}")
        }
    }
    // 프로젝트 추가 처리
    @PostMapping
    fun addProject(@RequestBody project: Project): ResponseEntity<Any> {
        val newProject = project.copy(finish = false) // 기본값 설정
        projectService.save(newProject)
        return ResponseEntity.ok("프로젝트 추가 성공")
    }

    // 프로젝트 수정 처리
    @PutMapping("/update/{id}")
    @ResponseBody
    fun updateProject(
        @PathVariable id: Int,
        @RequestBody updatedProject: Project
    ): ResponseEntity<String> {
        return try {
            projectService.updateProject(id, updatedProject)
            ResponseEntity.ok("프로젝트 수정 성공")
        } catch (e: Exception) {
            ResponseEntity.status(404).body("프로젝트 수정 실패: ${e.message}")
        }
    }
}
