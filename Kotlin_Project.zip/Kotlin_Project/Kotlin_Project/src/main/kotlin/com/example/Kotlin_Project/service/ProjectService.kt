package com.example.Kotlin_Project.service

import com.example.Kotlin_Project.model.Project
import com.example.Kotlin_Project.repository.ProjectRepository
import org.springframework.stereotype.Service

@Service
class ProjectService(private val projectRepository: ProjectRepository) {

    // 모든 프로젝트 조회
    fun findAll(): List<Project> = projectRepository.findAll()

    // 특정 프로젝트 조회
    fun findById(id: Int): Project? = projectRepository.findById(id).orElse(null)

    // 프로젝트 저장
    fun save(project: Project): Project = projectRepository.save(project)

    // 프로젝트 삭제
    fun deleteById(id: Int) = projectRepository.deleteById(id)

    fun updateProject(id: Int, updatedProject: Project): Project {
        val existingProject = projectRepository.findById(id).orElseThrow {
            NoSuchElementException("프로젝트를 찾을 수 없습니다: $id")
        }

        existingProject.projectName = updatedProject.projectName
        existingProject.description = updatedProject.description
        existingProject.start = updatedProject.start
        existingProject.end = updatedProject.end
        existingProject.finish = updatedProject.finish

        return projectRepository.save(existingProject)
    }
}

