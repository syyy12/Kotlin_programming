package com.example.Kotlin_Project.repository

import com.example.Kotlin_Project.model.ProjectMember
import com.example.Kotlin_Project.model.ProjectMemberId
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ProjectMemberRepository : JpaRepository<ProjectMember, ProjectMemberId>
