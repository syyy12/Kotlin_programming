package com.example.Kotlin_Project.service

import com.example.Kotlin_Project.model.ProjectMember
import com.example.Kotlin_Project.model.ProjectMemberId
import com.example.Kotlin_Project.repository.ProjectMemberRepository
import org.springframework.stereotype.Service
import com.example.Kotlin_Project.repository.EmployeeRepository
@Service
class ProjectMemberService(
    private val projectMemberRepository: ProjectMemberRepository,
    private val employeeRepository: EmployeeRepository
) {

    // 프로젝트에 멤버 추가
    fun addMemberToProject(projectMember: ProjectMember): ProjectMember {
        return projectMemberRepository.save(projectMember)
    }

    // 특정 프로젝트에 속한 멤버 조회
    fun findMembersByProjectId(projectId: Int): List<ProjectMember> {
        return projectMemberRepository.findAll().filter { it.id.projectId == projectId }
    }

    fun findMembersWithDetailsByProjectId(projectId: Int): List<Map<String, Any>> {
        val projectMembers = projectMemberRepository.findAll().filter { it.id.projectId == projectId }

        return projectMembers.map { member ->
            val employee = employeeRepository.findById(member.id.userId).orElse(null)
            mapOf(
                "member" to member,
                "employee" to employee
            )
        }
    }

    // 특정 멤버 삭제 (프로젝트에서 제거)
    fun removeMemberFromProject(userId: Int, projectId: Int) {
        val projectMemberId = ProjectMemberId(userId, projectId) // 복합 키 생성
        val memberToRemove = projectMemberRepository.findById(projectMemberId)
        memberToRemove.ifPresent { projectMemberRepository.delete(it) }
    }

    // 특정 멤버의 역할 업데이트
    fun updateMemberRole(userId: Int, projectId: Int, newRole: Int) {
        val projectMemberId = ProjectMemberId(userId, projectId) // 복합 키 생성
        val memberToUpdate = projectMemberRepository.findById(projectMemberId)

        memberToUpdate.ifPresent {
            val updatedMember = it.copy(role = newRole.toByte())
            projectMemberRepository.save(updatedMember)
        }
    }
}
