package com.example.Kotlin_Project.controller


import com.example.Kotlin_Project.model.Employee
import com.example.Kotlin_Project.service.EmployeeService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.stereotype.Controller

// 모델 사용
import org.springframework.ui.Model

@Controller
@RequestMapping("/employees") // API의 기본 경로 설정
class EmployeeController(private val employeeService: EmployeeService) {
    // 직원 추가
    @PostMapping
    fun addEmployee(@RequestBody employee: Employee): ResponseEntity<Employee> {
        val savedEmployee = employeeService.save(employee)
        return ResponseEntity.status(HttpStatus.CREATED).body(savedEmployee)
    }
    // 직원 삭제
    @DeleteMapping("/{id}")
    fun deleteEmployee(@PathVariable id: Int): ResponseEntity<Void> {
        val employee = employeeService.findById(id)
        return if (employee != null) {
            employeeService.deleteById(id)
            ResponseEntity.noContent().build() // 성공적으로 삭제
        } else {
            ResponseEntity.notFound().build() // 직원이 없으면 404 반환
        }
    }
    // 직원 목록 창 보기 위한
    @GetMapping("/view")
    fun viewEmployeesPage(model: Model): String {
        val employees = employeeService.findAll() // 직원 전체 조회
        model.addAttribute("employees", employees) // 데이터를 뷰로 전달
        return "employees" // templates/employees.html로 이동
    }
    // 직원 수정
    @PutMapping("/{id}")
    fun updateEmployee(@PathVariable id: Int, @RequestBody employee: Employee): ResponseEntity<Employee> {
        return try {
            val updatedEmployee = employeeService.updateEmployee(id, employee)
            ResponseEntity.ok(updatedEmployee) // 200 OK 응답
        } catch (e: NoSuchElementException) {
            ResponseEntity.notFound().build() // 404 Not Found 응답
        }
    }
    // 수정할 직원 조회
    @GetMapping("/{id}")
    fun getEmployeeById(@PathVariable id: Int): ResponseEntity<Employee> {
        return try {
            val employee = employeeService.findById(id)
            if (employee != null) {
                ResponseEntity.ok(employee)
            } else {
                ResponseEntity.notFound().build()
            }
        } catch (e: Exception) {
            ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build()
        }
    }
}

