package com.example.Kotlin_Project.controller

import com.example.Kotlin_Project.service.ProjectMemberService
import com.example.Kotlin_Project.service.ProjectService
import com.example.Kotlin_Project.service.EmployeeService
import com.example.Kotlin_Project.model.ProjectMember
import com.example.Kotlin_Project.model.ProjectMemberId
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.*

@Controller
@RequestMapping("/projectmember")
class ProjectMemberController(
    private val projectService: ProjectService,
    private val projectMemberService: ProjectMemberService,
    private val employeeService: EmployeeService
) {
    @GetMapping
    fun viewProjectMembers(@RequestParam("id") projectId: Int, model: Model): String {
        val project = projectService.findById(projectId)
            ?: throw Exception("프로젝트를 찾을 수 없습니다.")

        // 프로젝트에 속한 멤버 정보 가져오기
        val projectMembersWithDetails = projectMemberService.findMembersWithDetailsByProjectId(projectId)

        // 직원 정보 가져오기
        val allEmployees = employeeService.findAll()

        // 데이터를 모델에 추가
        model.addAttribute("project", project)
        model.addAttribute("projectMembersWithDetails", projectMembersWithDetails)
        model.addAttribute("allEmployees", allEmployees) // 직원 데이터 추가

        return "project-member" // Thymeleaf 템플릿 파일명
    }
    @PostMapping("/save")
    @ResponseBody
    fun saveProjectMember(@RequestBody memberData: Map<String, Any>): ResponseEntity<String> {
        try {
            val userId = (memberData["userId"] as Number).toInt()
            val projectId = (memberData["projectId"] as Number).toInt()
            val role = (memberData["role"] as Number).toInt().toByte()
            val taskName = memberData["taskName"] as? String
            val taskDescription = memberData["taskDescription"] as? String

            // 복합 키 생성
            val projectMemberId = ProjectMemberId(userId, projectId)

            // ProjectMember 객체 생성
            val newMember = ProjectMember(
                id = projectMemberId,
                role = role,
                taskName = taskName,
                taskDescription = taskDescription
            )

            println("테스트용입니다.")
            println(newMember)

            projectMemberService.addMemberToProject(newMember)
            return ResponseEntity.ok("멤버가 성공적으로 추가되었습니다.")
        } catch (e: Exception) {
            println("오류 발생: ${e.message}")
            return ResponseEntity.badRequest().body("오류 발생: ${e.message}")
        }
    }





}
