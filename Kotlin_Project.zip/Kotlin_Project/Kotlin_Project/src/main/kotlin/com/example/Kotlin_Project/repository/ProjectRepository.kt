package com.example.Kotlin_Project.repository

import com.example.Kotlin_Project.model.Project
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ProjectRepository : JpaRepository<Project, Int> {
    fun findByProjectNameContaining(keyword: String): List<Project>
}
