package com.example.Kotlin_Project.model

import jakarta.persistence.*
import java.io.Serializable

@Embeddable
data class ProjectMemberId(
    @Column(name = "user_id", nullable = false)
    val userId: Int = 0,

    @Column(name = "project_id", nullable = false)
    val projectId: Int = 0
) : Serializable {
    // 기본 생성자 추가
    constructor() : this(0, 0)
}
@Entity
@Table(name = "project_member")
data class ProjectMember(
    @EmbeddedId
    val id: ProjectMemberId = ProjectMemberId(), // 기본값을 추가

    @Column(name = "role", nullable = false)
    val role: Byte = 0,

    @Column(name = "task_name", length = 45)
    val taskName: String? = null,

    @Column(name = "task_description", length = 100)
    val taskDescription: String? = null
) {
    // Hibernate가 사용할 기본 생성자 추가
    constructor() : this(ProjectMemberId(), 0, null, null)
}