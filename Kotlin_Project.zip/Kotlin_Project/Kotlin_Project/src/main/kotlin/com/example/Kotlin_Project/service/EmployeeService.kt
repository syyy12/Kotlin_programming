package com.example.Kotlin_Project.service

import com.example.Kotlin_Project.model.Employee
import com.example.Kotlin_Project.repository.EmployeeRepository
import org.springframework.stereotype.Service

@Service
class EmployeeService(private val employeeRepository: EmployeeRepository) {

    // 직원 전체 조회
    fun findAll(): List<Employee> = employeeRepository.findAll()


    // 특정 직원 조회
    fun findById(id: Int): Employee? = employeeRepository.findById(id).orElse(null)

    // 직원 추가
    fun save(employee: Employee): Employee = employeeRepository.save(employee)

    // 직원 삭제
    fun deleteById(id: Int) = employeeRepository.deleteById(id)


    // 직원 수정
    fun updateEmployee(id: Int, updatedEmployee: Employee): Employee {
        val existingEmployee = employeeRepository.findById(id).orElseThrow {
            throw NoSuchElementException("직원이 존재하지 않습니다: $id")
        }

        // 기존 데이터 업데이트
        val newEmployee = existingEmployee.copy(
            name = updatedEmployee.name,
            specialty = updatedEmployee.specialty,
            userEmail = updatedEmployee.userEmail
        )
        return employeeRepository.save(newEmployee)
    }
}
