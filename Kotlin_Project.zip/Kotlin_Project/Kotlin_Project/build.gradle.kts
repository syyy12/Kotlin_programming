plugins {
	kotlin("jvm") version "1.9.25"
	kotlin("plugin.spring") version "1.9.25"
	id("org.springframework.boot") version "3.3.6"
	id("io.spring.dependency-management") version "1.1.6"
}

group = "com.example"
version = "0.0.1-SNAPSHOT"

java {
	toolchain {
		languageVersion = JavaLanguageVersion.of(17)
	}
}

configurations {
	compileOnly {
		extendsFrom(configurations.annotationProcessor.get())
	}
}

repositories {
	mavenCentral()
}

dependencies {
	// Spring Boot 웹 개발을 위한 기본 의존성 (Spring MVC)
	implementation("org.springframework.boot:spring-boot-starter-web")
	// Thymeleaf 템플릿 엔진
	implementation("org.springframework.boot:spring-boot-starter-thymeleaf")
	// Spring Data JPA (MySQL과 연동을 위한 ORM)
	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
	// Kotlin 관련 필수 의존성
	implementation("com.fasterxml.jackson.module:jackson-module-kotlin")
	implementation("org.jetbrains.kotlin:kotlin-reflect")
	// MySQL 데이터베이스 드라이버
	runtimeOnly("mysql:mysql-connector-java:8.0.32")
	// 테스트 관련 의존성
	testImplementation("org.springframework.boot:spring-boot-starter-test")
	testImplementation("org.jetbrains.kotlin:kotlin-test-junit5")

	implementation("org.springframework.boot:spring-boot-devtools")
}


kotlin {
	compilerOptions {
		freeCompilerArgs.addAll("-Xjsr305=strict")
	}
}

tasks.withType<Test> {
	useJUnitPlatform()
}
