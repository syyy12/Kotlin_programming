package com.example.Kotlin_Project

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KotlinProjectApplicationTests {

	@Test
	fun contextLoads() {
	}

}
