package com.example.Kotlin_Project.model

import jakarta.persistence.*
import java.time.LocalDate

@Entity // 데이터베이스 테이블과 매핑
@Table(name = "project") // 테이블 이름 지정
data class Project(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto Increment 설정
    @Column(name = "project_id")
    val projectId: Int = 0, // 기본값 0

    @Column(name = "project_name", nullable = false, length = 45) // NOT NULL, VARCHAR(45)
    var projectName: String = "",

    @Column(name = "description", nullable = false, length = 200) // NOT NULL, VARCHAR(200)
    var description: String = "",

    @Column(name = "start", nullable = false) // NOT NULL, DATE
    var start: LocalDate = LocalDate.now(),

    @Column(name = "end", nullable = false) // NOT NULL, DATE
    var end: LocalDate = LocalDate.now(),

    @Column(name = "finish", nullable = false) // NOT NULL, TINYINT
    var finish: Boolean = false // 기본값 false
) {
    // JPA가 필요로 하는 기본 생성자
    constructor() : this(0, "", "", LocalDate.now(), LocalDate.now(), false)
}

